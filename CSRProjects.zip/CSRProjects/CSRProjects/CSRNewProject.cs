﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace CSRProjects
{
    public partial class CSRNewProject : Form
    {
        StreamWriter writer;
        StreamReader reader;
        string record = "";
        string errors = "";
        string txtFilePath = "";
        string txtFileProject = @"C:\Users\shane\OneDrive\USB\Work\C\CSRProjects\Projects.txt";
        public CSRNewProject()
        {
            InitializeComponent();
        }

        //Does all validation checks and if correct, writes to the projects text file
        private void btnSave_Click(object sender, EventArgs e)
        {
            Label[] labels = new Label[4] {lblProjID, lblProjName, lblDesc, lblToDo };
            RichTextBox[] fields = new RichTextBox[4] {txtProjID, txtProjName, txtDesc, txtToDo};
            for (int i = 0;i<= 3;i++)
            {
                if (Validation(fields[i].Text))
                {
                    fields[i].Text = Capitalize(fields[i].Text);
                }
                else
                {
                    errors += $"Problem with {labels[i].Text}, make sure it is filled out\n";
                }
            }
            
            if (!IsInteger(fields[0].Text))
            {
                errors += $"Project ID can only be numbers\n";
            }
            Duplicates(fields[0].Text);
            if (errors == "")
            {
                string newProject = $"{fields[0].Text}:{fields[1].Text}:{fields[2].Text}:{fields[3].Text}";
                MessageBox.Show(newProject);
                txtFilePath = @"C:\Users\shane\OneDrive\USB\Work\C\CSRProjects\"+txtProjID.Text+".txt";
                if (!File.Exists(txtFilePath))
                {
                    FileStream fs = File.Create(txtFilePath);
                    fs.Close();
                }
                writer = new StreamWriter(txtFileProject, append: true);
                writer.WriteLine(newProject);
                writer.Close();
                MessageBox.Show("Project Successfully Added!");
            }
            else
            {
                MessageBox.Show(errors);
                errors = "";
            }

        }

        //Clears all text fields
        private void btnClear_Click(object sender, EventArgs e)
        {
            RichTextBox[] fields = new RichTextBox[4] { txtProjID, txtProjName, txtDesc, txtToDo };
            for (int i = 0; i <= 3; i++)
            {
                fields[i].Text = "";
            }
        }

        //closes the form
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Checks to see if input is integer
        public bool IsInteger(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return false;
            try
            {
                int IsInteger = Convert.ToInt32(input);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        //Makes sure there are no duplicate projects
        public void Duplicates(string input)
        {
            reader = new StreamReader(txtFileProject);
            while (!reader.EndOfStream)
            {
                record = reader.ReadLine();
                string[] ProjectID = record.Split(new string[] { ":" }, StringSplitOptions.None);
                if (ProjectID[0] == input)
                {
                    errors += "That Project ID already exists, please choose a new one\n";
                }
            }
            reader.Close();
        }

        //Checks for any empty fields
        private bool Validation(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return false;
            }
            return true;
        }

        //Capitializes all inputs
        public static string Capitalize(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return null;
            }

            char[] array = input.ToLower().ToCharArray();
            array[0] = char.ToUpper(array[0]);

            for (int i = 1; i < array.Length; i++)
            {
                if (char.IsWhiteSpace(array[i - 1]))
                {
                    array[i] = char.ToUpper(array[i]);
                }
            }
            return new string(array);
        }
    }
}
