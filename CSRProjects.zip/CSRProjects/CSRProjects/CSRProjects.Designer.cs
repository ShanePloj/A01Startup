﻿namespace CSRProjects
{
    partial class CSRProjects
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtProjID = new System.Windows.Forms.TextBox();
            this.txtProjName = new System.Windows.Forms.TextBox();
            this.btnSearchProj = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStoreName = new System.Windows.Forms.TextBox();
            this.btnSearchStore = new System.Windows.Forms.Button();
            this.txtDesc = new System.Windows.Forms.RichTextBox();
            this.txtNotes = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmbFilterProvince = new System.Windows.Forms.ComboBox();
            this.cmbFilterCity = new System.Windows.Forms.ComboBox();
            this.cmbFilterStatus = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lstDisplay = new System.Windows.Forms.ListBox();
            this.txtNotStarted = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPartial = new System.Windows.Forms.TextBox();
            this.txtCompleted = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtToDo = new System.Windows.Forms.RichTextBox();
            this.gbCash1 = new System.Windows.Forms.GroupBox();
            this.cmbCash1 = new System.Windows.Forms.ComboBox();
            this.gbCash2 = new System.Windows.Forms.GroupBox();
            this.cmbCash2 = new System.Windows.Forms.ComboBox();
            this.gbCash3 = new System.Windows.Forms.GroupBox();
            this.cmbCash3 = new System.Windows.Forms.ComboBox();
            this.gbCash4 = new System.Windows.Forms.GroupBox();
            this.cmbCash4 = new System.Windows.Forms.ComboBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.gbCash5 = new System.Windows.Forms.GroupBox();
            this.cmbCash5 = new System.Windows.Forms.ComboBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.gbCash1.SuspendLayout();
            this.gbCash2.SuspendLayout();
            this.gbCash3.SuspendLayout();
            this.gbCash4.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.gbCash5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Project ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Project Name";
            // 
            // txtProjID
            // 
            this.txtProjID.Location = new System.Drawing.Point(93, 20);
            this.txtProjID.Name = "txtProjID";
            this.txtProjID.Size = new System.Drawing.Size(111, 20);
            this.txtProjID.TabIndex = 2;
            // 
            // txtProjName
            // 
            this.txtProjName.BackColor = System.Drawing.Color.White;
            this.txtProjName.ForeColor = System.Drawing.Color.Black;
            this.txtProjName.Location = new System.Drawing.Point(93, 43);
            this.txtProjName.Name = "txtProjName";
            this.txtProjName.ReadOnly = true;
            this.txtProjName.Size = new System.Drawing.Size(215, 20);
            this.txtProjName.TabIndex = 3;
            // 
            // btnSearchProj
            // 
            this.btnSearchProj.Location = new System.Drawing.Point(212, 19);
            this.btnSearchProj.Name = "btnSearchProj";
            this.btnSearchProj.Size = new System.Drawing.Size(95, 21);
            this.btnSearchProj.TabIndex = 4;
            this.btnSearchProj.Text = "Search";
            this.btnSearchProj.UseVisualStyleBackColor = true;
            this.btnSearchProj.Click += new System.EventHandler(this.btnSearchProj_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Store Name";
            // 
            // txtStoreName
            // 
            this.txtStoreName.Location = new System.Drawing.Point(111, 110);
            this.txtStoreName.Name = "txtStoreName";
            this.txtStoreName.Size = new System.Drawing.Size(111, 20);
            this.txtStoreName.TabIndex = 6;
            // 
            // btnSearchStore
            // 
            this.btnSearchStore.Location = new System.Drawing.Point(231, 109);
            this.btnSearchStore.Name = "btnSearchStore";
            this.btnSearchStore.Size = new System.Drawing.Size(95, 21);
            this.btnSearchStore.TabIndex = 7;
            this.btnSearchStore.Text = "Search";
            this.btnSearchStore.UseVisualStyleBackColor = true;
            this.btnSearchStore.Click += new System.EventHandler(this.btnSearchStore_Click);
            // 
            // txtDesc
            // 
            this.txtDesc.BackColor = System.Drawing.Color.White;
            this.txtDesc.Location = new System.Drawing.Point(6, 17);
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.ReadOnly = true;
            this.txtDesc.Size = new System.Drawing.Size(200, 78);
            this.txtDesc.TabIndex = 9;
            this.txtDesc.Text = "";
            // 
            // txtNotes
            // 
            this.txtNotes.BackColor = System.Drawing.Color.White;
            this.txtNotes.Location = new System.Drawing.Point(14, 18);
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.ReadOnly = true;
            this.txtNotes.Size = new System.Drawing.Size(736, 55);
            this.txtNotes.TabIndex = 27;
            this.txtNotes.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSearchProj);
            this.groupBox1.Controls.Add(this.txtProjName);
            this.groupBox1.Controls.Add(this.txtProjID);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(17, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(327, 76);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Projects";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtNotes);
            this.groupBox2.Location = new System.Drawing.Point(15, 411);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(761, 84);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Notes";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmbFilterProvince);
            this.groupBox3.Controls.Add(this.cmbFilterCity);
            this.groupBox3.Controls.Add(this.cmbFilterStatus);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.lstDisplay);
            this.groupBox3.Controls.Add(this.txtNotStarted);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtPartial);
            this.groupBox3.Controls.Add(this.txtCompleted);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(17, 190);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(759, 194);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "List Of Stores";
            // 
            // cmbFilterProvince
            // 
            this.cmbFilterProvince.FormattingEnabled = true;
            this.cmbFilterProvince.Items.AddRange(new object[] {
            "N/A"});
            this.cmbFilterProvince.Location = new System.Drawing.Point(320, 20);
            this.cmbFilterProvince.Name = "cmbFilterProvince";
            this.cmbFilterProvince.Size = new System.Drawing.Size(121, 21);
            this.cmbFilterProvince.TabIndex = 36;
            this.cmbFilterProvince.SelectedIndexChanged += new System.EventHandler(this.cmbFilterProvince_SelectedIndexChanged);
            // 
            // cmbFilterCity
            // 
            this.cmbFilterCity.FormattingEnabled = true;
            this.cmbFilterCity.Items.AddRange(new object[] {
            "N/A"});
            this.cmbFilterCity.Location = new System.Drawing.Point(193, 20);
            this.cmbFilterCity.Name = "cmbFilterCity";
            this.cmbFilterCity.Size = new System.Drawing.Size(121, 21);
            this.cmbFilterCity.TabIndex = 35;
            this.cmbFilterCity.SelectedIndexChanged += new System.EventHandler(this.cmbFilterCity_SelectedIndexChanged);
            // 
            // cmbFilterStatus
            // 
            this.cmbFilterStatus.FormattingEnabled = true;
            this.cmbFilterStatus.Items.AddRange(new object[] {
            "Completed",
            "Partial",
            "Not Started"});
            this.cmbFilterStatus.Location = new System.Drawing.Point(66, 20);
            this.cmbFilterStatus.Name = "cmbFilterStatus";
            this.cmbFilterStatus.Size = new System.Drawing.Size(121, 21);
            this.cmbFilterStatus.TabIndex = 34;
            this.cmbFilterStatus.SelectedIndexChanged += new System.EventHandler(this.cmbFilterStatus_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 33;
            this.label7.Text = "Filter By:";
            // 
            // lstDisplay
            // 
            this.lstDisplay.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstDisplay.FormattingEnabled = true;
            this.lstDisplay.ItemHeight = 14;
            this.lstDisplay.Location = new System.Drawing.Point(16, 53);
            this.lstDisplay.Name = "lstDisplay";
            this.lstDisplay.Size = new System.Drawing.Size(643, 130);
            this.lstDisplay.TabIndex = 31;
            this.lstDisplay.SelectedIndexChanged += new System.EventHandler(this.lstDisplay_SelectedIndexChanged);
            // 
            // txtNotStarted
            // 
            this.txtNotStarted.Location = new System.Drawing.Point(672, 157);
            this.txtNotStarted.Name = "txtNotStarted";
            this.txtNotStarted.ReadOnly = true;
            this.txtNotStarted.Size = new System.Drawing.Size(76, 20);
            this.txtNotStarted.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(679, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "Not Started";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(691, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Partial";
            // 
            // txtPartial
            // 
            this.txtPartial.Location = new System.Drawing.Point(672, 98);
            this.txtPartial.Name = "txtPartial";
            this.txtPartial.ReadOnly = true;
            this.txtPartial.Size = new System.Drawing.Size(76, 20);
            this.txtPartial.TabIndex = 27;
            // 
            // txtCompleted
            // 
            this.txtCompleted.Location = new System.Drawing.Point(672, 40);
            this.txtCompleted.Name = "txtCompleted";
            this.txtCompleted.ReadOnly = true;
            this.txtCompleted.Size = new System.Drawing.Size(76, 20);
            this.txtCompleted.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(679, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Completed";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(582, 390);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(95, 21);
            this.btnCancel.TabIndex = 34;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(481, 390);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(95, 21);
            this.btnSave.TabIndex = 33;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.Location = new System.Drawing.Point(25, 386);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(95, 21);
            this.btnNew.TabIndex = 32;
            this.btnNew.Text = "New Project";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtDesc);
            this.groupBox4.Location = new System.Drawing.Point(346, 25);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(212, 101);
            this.groupBox4.TabIndex = 35;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Project Description";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtToDo);
            this.groupBox5.Location = new System.Drawing.Point(564, 25);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(212, 101);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "To Do List";
            // 
            // txtToDo
            // 
            this.txtToDo.BackColor = System.Drawing.Color.White;
            this.txtToDo.Location = new System.Drawing.Point(6, 17);
            this.txtToDo.Name = "txtToDo";
            this.txtToDo.ReadOnly = true;
            this.txtToDo.Size = new System.Drawing.Size(200, 78);
            this.txtToDo.TabIndex = 9;
            this.txtToDo.Text = "";
            // 
            // gbCash1
            // 
            this.gbCash1.Controls.Add(this.cmbCash1);
            this.gbCash1.Location = new System.Drawing.Point(293, 137);
            this.gbCash1.Name = "gbCash1";
            this.gbCash1.Size = new System.Drawing.Size(93, 47);
            this.gbCash1.TabIndex = 37;
            this.gbCash1.TabStop = false;
            this.gbCash1.Text = "Cash 1";
            // 
            // cmbCash1
            // 
            this.cmbCash1.FormattingEnabled = true;
            this.cmbCash1.Items.AddRange(new object[] {
            "N/A",
            "Completed",
            "Partial",
            "Not Started"});
            this.cmbCash1.Location = new System.Drawing.Point(6, 19);
            this.cmbCash1.Name = "cmbCash1";
            this.cmbCash1.Size = new System.Drawing.Size(81, 21);
            this.cmbCash1.TabIndex = 3;
            // 
            // gbCash2
            // 
            this.gbCash2.Controls.Add(this.cmbCash2);
            this.gbCash2.Location = new System.Drawing.Point(392, 137);
            this.gbCash2.Name = "gbCash2";
            this.gbCash2.Size = new System.Drawing.Size(93, 47);
            this.gbCash2.TabIndex = 38;
            this.gbCash2.TabStop = false;
            this.gbCash2.Text = "Cash 2";
            // 
            // cmbCash2
            // 
            this.cmbCash2.FormattingEnabled = true;
            this.cmbCash2.Items.AddRange(new object[] {
            "N/A",
            "Completed",
            "Partial",
            "Not Started"});
            this.cmbCash2.Location = new System.Drawing.Point(6, 19);
            this.cmbCash2.Name = "cmbCash2";
            this.cmbCash2.Size = new System.Drawing.Size(81, 21);
            this.cmbCash2.TabIndex = 2;
            // 
            // gbCash3
            // 
            this.gbCash3.Controls.Add(this.cmbCash3);
            this.gbCash3.Location = new System.Drawing.Point(491, 137);
            this.gbCash3.Name = "gbCash3";
            this.gbCash3.Size = new System.Drawing.Size(93, 47);
            this.gbCash3.TabIndex = 38;
            this.gbCash3.TabStop = false;
            this.gbCash3.Text = "Cash 3";
            // 
            // cmbCash3
            // 
            this.cmbCash3.FormattingEnabled = true;
            this.cmbCash3.Items.AddRange(new object[] {
            "N/A",
            "Completed",
            "Partial",
            "Not Started"});
            this.cmbCash3.Location = new System.Drawing.Point(6, 19);
            this.cmbCash3.Name = "cmbCash3";
            this.cmbCash3.Size = new System.Drawing.Size(81, 21);
            this.cmbCash3.TabIndex = 3;
            // 
            // gbCash4
            // 
            this.gbCash4.Controls.Add(this.cmbCash4);
            this.gbCash4.Location = new System.Drawing.Point(590, 137);
            this.gbCash4.Name = "gbCash4";
            this.gbCash4.Size = new System.Drawing.Size(93, 47);
            this.gbCash4.TabIndex = 38;
            this.gbCash4.TabStop = false;
            this.gbCash4.Text = "Cash 4";
            // 
            // cmbCash4
            // 
            this.cmbCash4.FormattingEnabled = true;
            this.cmbCash4.Items.AddRange(new object[] {
            "N/A",
            "Completed",
            "Partial",
            "Not Started"});
            this.cmbCash4.Location = new System.Drawing.Point(6, 19);
            this.cmbCash4.Name = "cmbCash4";
            this.cmbCash4.Size = new System.Drawing.Size(81, 21);
            this.cmbCash4.TabIndex = 3;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.cmbStatus);
            this.groupBox10.Location = new System.Drawing.Point(21, 137);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(126, 47);
            this.groupBox10.TabIndex = 38;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Status";
            // 
            // cmbStatus
            // 
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Completed",
            "Partial",
            "Not Started"});
            this.cmbStatus.Location = new System.Drawing.Point(6, 19);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(114, 21);
            this.cmbStatus.TabIndex = 3;
            this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.cmbStatus_SelectedIndexChanged);
            // 
            // gbCash5
            // 
            this.gbCash5.Controls.Add(this.cmbCash5);
            this.gbCash5.Location = new System.Drawing.Point(683, 137);
            this.gbCash5.Name = "gbCash5";
            this.gbCash5.Size = new System.Drawing.Size(93, 47);
            this.gbCash5.TabIndex = 39;
            this.gbCash5.TabStop = false;
            this.gbCash5.Text = "Cash 5";
            // 
            // cmbCash5
            // 
            this.cmbCash5.FormattingEnabled = true;
            this.cmbCash5.Items.AddRange(new object[] {
            "N/A",
            "Completed",
            "Partial",
            "Not Started"});
            this.cmbCash5.Location = new System.Drawing.Point(6, 19);
            this.cmbCash5.Name = "cmbCash5";
            this.cmbCash5.Size = new System.Drawing.Size(81, 21);
            this.cmbCash5.TabIndex = 3;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(681, 390);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(95, 21);
            this.btnExit.TabIndex = 40;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // CSRProjects
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 507);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.gbCash5);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.gbCash2);
            this.Controls.Add(this.gbCash3);
            this.Controls.Add(this.gbCash4);
            this.Controls.Add(this.gbCash1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSearchStore);
            this.Controls.Add(this.txtStoreName);
            this.Controls.Add(this.label3);
            this.Name = "CSRProjects";
            this.Text = "Computer Solutions Repair - Projects";
            this.Load += new System.EventHandler(this.CSRProjects_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.gbCash1.ResumeLayout(false);
            this.gbCash2.ResumeLayout(false);
            this.gbCash3.ResumeLayout(false);
            this.gbCash4.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.gbCash5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtProjID;
        private System.Windows.Forms.TextBox txtProjName;
        private System.Windows.Forms.Button btnSearchProj;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtStoreName;
        private System.Windows.Forms.Button btnSearchStore;
        private System.Windows.Forms.RichTextBox txtDesc;
        private System.Windows.Forms.RichTextBox txtNotes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RichTextBox txtToDo;
        private System.Windows.Forms.GroupBox gbCash1;
        private System.Windows.Forms.GroupBox gbCash2;
        private System.Windows.Forms.GroupBox gbCash3;
        private System.Windows.Forms.GroupBox gbCash4;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ComboBox cmbCash1;
        private System.Windows.Forms.ComboBox cmbCash2;
        private System.Windows.Forms.ComboBox cmbCash3;
        private System.Windows.Forms.ComboBox cmbCash4;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.TextBox txtPartial;
        private System.Windows.Forms.TextBox txtCompleted;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox gbCash5;
        private System.Windows.Forms.ComboBox cmbCash5;
        private System.Windows.Forms.TextBox txtNotStarted;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lstDisplay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbFilterProvince;
        private System.Windows.Forms.ComboBox cmbFilterCity;
        private System.Windows.Forms.ComboBox cmbFilterStatus;
        private System.Windows.Forms.Button btnExit;
    }
}

