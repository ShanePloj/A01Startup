﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace SPWorkingProject.SPUtilityClasses
{
    public static class SPStringUtilites
    {
        public static string Capitalize(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return null;
            }

            char[] array = input.ToLower().ToCharArray();
            array[0] = char.ToUpper(array[0]);

            for (int i = 1; i < array.Length; i++)
            {
                if (char.IsWhiteSpace(array[i - 1]))
                {
                    array[i] = char.ToUpper(array[i]);
                }
            }
            return new string(array);
        }

        public static string NonDigits(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return null;
            }
            return Regex.Replace(input, @"[^\d]", string.Empty);
        }

        public static string PhoneNumber(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return null;
            }

            if (input.Length == 7)
            {
                return input.Insert(3, "-");
            }

            else if (input.Length == 10)
            {
                return input.Insert(3, "-").Insert(7, "-");
            }

            return null;
        }

        public static string PostalCode(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return null;
            }
            input.ToUpper().Insert(3, string.Empty);
            if (input.Length == 6)
            {
                return input;
            }
            return null;
        }

        public static string Format(string input)
        {

            if (string.IsNullOrWhiteSpace(input))
            {
                return null;
            }

            if (input.Length == 5)
            {
                return input;
            }

            else if (input.Length == 9)
            {
                return input.Insert(5, "-");
            }

            return null;
        }

        public static string FullName(string firstName, string lastName)
        {
            if (string.IsNullOrWhiteSpace(firstName) && string.IsNullOrWhiteSpace(lastName))
            {
                return null;
            }

            else if (string.IsNullOrWhiteSpace(firstName))
            {
                return Capitalize(lastName);
            }

            else if (string.IsNullOrWhiteSpace(lastName))
            {
                return Capitalize(firstName);
            }

            return Capitalize(lastName + ", " + firstName);
        }
    }
}
