﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SPWorkingProject.SPUtilityClasses
{
    public static class SPNumericUtilites
    {
        //Checks to see if the string is a number
        public static bool IsNumeric(string input)
        {
            Regex number = new Regex("^-?(0|[1-9]\\d*)(\\.\\d+)?$");
            if (string.IsNullOrWhiteSpace(input))
                return false;
            try
            {
                if (number.IsMatch(input))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception e)
            {
                return false;
            }

        }

        //Checks to see if the object is a number
        public static bool IsNumeric(object input)
        {
            if (input == null)
                return false;

            return input is double || input is int;

        }

        //Checks to see if a string is an int
        public static bool IsInteger(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return false;
            try
            {
                int IsInteger = Convert.ToInt32(input);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        //Checks to see if an object is an int
        public static bool IsInteger(object input)
        {
            if (input == null)
                return false;

            return input is int;
        }

        //Check to see if a double is an int
        public static bool IsInteger(double input)
        {
            return (input % 1) == 0;
        }

        //Returns a string if the input minus any characters is numeric
        public static string NonNumericCharacters(string input)
        {
            input = Regex.Replace(input, "[^-0-9.]", string.Empty);
            return input;
        }

        public static void keyPressed(KeyPressEventArgs input)
        {
            if (!char.IsDigit(input.KeyChar))
            {
                input.Handled = true;
            }
        }
    }
}
