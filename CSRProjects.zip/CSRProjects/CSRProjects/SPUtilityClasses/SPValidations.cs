﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace SPWorkingProject.SPUtilityClasses
{
    public static class SPValidations
    {
        public static bool CAPostalCode(string input)
        {
            Regex postalCode = new Regex(@"^[ABCEGHJKLMNPRSTVXY]\d[ABCEGHJKLMNPRSTVWXYZ] ?\d[ABCEGHJKLMNPRSTVWXYZ]\d$", RegexOptions.IgnoreCase);
            if (postalCode.IsMatch(input))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool USZipCode(string input)
        {
            SPNumericUtilites.IsInteger(input);
            if (input.Length == 5 || input.Length == 9)
            {
                return true;
            }
            return false;
        }
        
        public static bool PhoneNumber(string input)
        {
            SPStringUtilites.NonDigits(input);
            if (input.Length == 10)
            {
                return true;
            }
            return false;
        }
    }
}
