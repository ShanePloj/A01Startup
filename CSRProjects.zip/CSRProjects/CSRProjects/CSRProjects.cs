﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace CSRProjects
{
    public partial class CSRProjects : Form
    {
        StreamWriter writer;
        StreamReader readerClient;
        StreamReader readerProject;
        string record = "";
        string recordProj = "";
        string txtFileClient = @"C:\Users\shane\OneDrive\USB\Work\C\CSRProjects\1.txt";
        string txtFileProject = @"C:\Users\shane\OneDrive\USB\Work\C\CSRProjects\Projects.txt";
        public CSRProjects()
        {
            InitializeComponent();
        }

        private void CSRProjects_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists(txtFileClient.Substring(0, txtFileClient.LastIndexOf('\\'))))
            {
                txtNotes.Text = ("Path to target file does not exist");
            }
            if (!Directory.Exists(txtFileProject.Substring(0, txtFileProject.LastIndexOf('\\'))))
            {
                txtNotes.Text = ("Path to target file does not exist");
            }
            FillCombos();
            StoreList();
            ChangeVisibility();
            Populate("Proj");


        }
        private void FillCombos()
        {
            cmbFilterCity.Items.Clear();
            cmbFilterProvince.Items.Clear();
            readerClient = new StreamReader(txtFileClient);
            while (!readerClient.EndOfStream)
            {
                record = readerClient.ReadLine();
                string[] Client = record.Split(new string[] { ":" }, StringSplitOptions.None);
                if (!cmbFilterCity.Items.Contains(Client[2]))
                {
                    cmbFilterCity.Items.Add(Client[2]);
                }
                if (!cmbFilterProvince.Items.Contains(Client[3]))
                {
                    cmbFilterProvince.Items.Add(Client[3]);
                }
            }
            readerClient.Close();
        }
        private void StoreList()
        {

            readerProject = new StreamReader(txtFileProject);
            string[] Client = record.Split(new string[] { ":" }, StringSplitOptions.None);
            if (txtProjID.Text == "")
            {
                txtProjID.Text = "1";
            }
            while (!readerProject.EndOfStream)
            {
                recordProj = readerProject.ReadLine();
                string[] Project = recordProj.Split(new string[] { ":" }, StringSplitOptions.None);
                if (Project[0] == txtProjID.Text)
                {
                    txtProjID.Text = Project[0];
                    txtProjName.Text = Project[1];
                    txtDesc.Text = Project[2];
                    txtToDo.Text = Project[3];
                }
            }

            txtStoreName.Text = $"{Client[0]}, {Client[1]}";
            cmbStatus.SelectedItem = Client[4];
            cmbCash1.SelectedItem = Client[5];
            cmbCash2.SelectedItem = Client[6];
            cmbCash3.SelectedItem = Client[7];
            cmbCash4.SelectedItem = Client[8];
            cmbCash5.SelectedItem = Client[9];
            txtNotes.Text = Client[10];
            readerProject.Close();
        }



        private void lstDisplay_SelectedIndexChanged(object sender, EventArgs e)
        {
            string temp;
            string tempRecord;
            readerClient = new StreamReader(txtFileClient);
            while (!readerClient.EndOfStream)
            {
                record = readerClient.ReadLine();
                tempRecord = record.Replace(":", "").Replace(" ", "").Trim();
                temp = lstDisplay.Text;
                temp = temp.Replace("Completed", "").Replace("Partial", "").Replace("Not Started", "").Replace(",", "").Replace(" ", "").Trim();
                if (tempRecord.Contains(temp))
                {
                    StoreList();
                    ChangeVisibility();
                }
            }
            readerClient.Close();
        }

        //Search by Project ID
        private void btnSearchProj_Click(object sender, EventArgs e)
        {
            readerProject = new StreamReader(txtFileProject);
            try
            {
                txtFileClient = $"C:\\Users\\shane\\OneDrive\\USB\\Work\\C\\CSRProjects\\{txtProjID.Text}.txt";
                Populate("Proj");
                StoreList();
                FillCombos();
            }
            catch
            {
                MessageBox.Show("There is no Project with that ID");
            }
            readerProject.Close();
        }
        //Search by Store Name
        private void btnSearchStore_Click(object sender, EventArgs e)
        {
            Populate("Store");
        }

        //If you change the status to either "completed" or "not started" then it will change all the cashes to the respected selection
        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox[] cmbCashs = new ComboBox[5] { cmbCash1, cmbCash2, cmbCash3, cmbCash4, cmbCash5 };

            for (int i = 0; i <= 4; i++)
            {
                if (cmbStatus.SelectedIndex == 0) //Completed
                {
                    if (cmbCashs[i].Visible)
                    {
                        cmbCashs[i].SelectedItem = "Completed";
                    }
                }
                if (cmbStatus.SelectedIndex == 2) //Not Started
                {
                    if (cmbCashs[i].Visible)
                    {
                        cmbCashs[i].SelectedItem = "Not Started";
                    }
                }
            }
        }

        //Saves any changes to the Text File that we're made on the .exe regarding the cashes/Status
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (lstDisplay.SelectedIndex >= 2 || lstDisplay.SelectedIndex == lstDisplay.Items.Count - 1)
            {
                readerClient = new StreamReader(txtFileClient);
                string[] Export = new string[7];
                List<string> records = new List<string>();
                string tempDisplay = "";
                string tempPC = "";
                while (!readerClient.EndOfStream)
                {
                    record = readerClient.ReadLine();
                    tempPC = record.Replace(":", "").Replace(" ", "").Trim();
                    string[] Client = record.Split(new string[] { ":" }, StringSplitOptions.None);

                    tempDisplay = lstDisplay.Text;
                    tempDisplay = tempDisplay.Replace("Completed", "").Replace("Partial", "").Replace("Not Started", "").Replace(",", "").Replace(" ", "").Trim();
                    Export[0] = cmbStatus.Text;
                    Export[1] = cmbCash1.Text;
                    Export[2] = cmbCash2.Text;
                    Export[3] = cmbCash3.Text;
                    Export[4] = cmbCash4.Text;
                    Export[5] = cmbCash5.Text;
                    Export[6] = txtNotes.Text;
                    if (tempPC.Contains(tempDisplay))
                    {
                        records.Add($"{Client[0]}:{Client[1]}:{Client[2]}:{Client[3]}:{Export[0]}:{Export[1]}:{Export[2]}:{Export[3]}:{Export[4]}:{Export[5]}:{Export[6]}");
                    }
                    else
                    {
                        records.Add(record);
                    }
                }
                readerClient.Close();
                writer = new StreamWriter(txtFileClient, append: false);
                records.ForEach(writer.WriteLine);
                writer.Close();
                Populate("Proj");
            }
        }

        //Cancel any and all changes made before the "save" button has been hit - If save is hit "Cancel" will do nothing
        private void btnCancel_Click(object sender, EventArgs e)
        {
            readerClient = new StreamReader(txtFileClient);
            record = readerClient.ReadLine();
            string[] Client = record.Split(new string[] { ":" }, StringSplitOptions.None);

            StoreList();
            ChangeVisibility();
            lstDisplay.ClearSelected();
            readerClient.Close();
        }

        private void Populate(string populate)
        {
           

            readerClient = new StreamReader(txtFileClient);
            int completed = 0;
            int partial = 0;
            int notStarted = 0;
            int count = 0;
            lstDisplay.Items.Clear();
            lstDisplay.Items.Add(String.Format("{0, -20}{1, 15}{2, 15}{3, 15}", "Name", "Status", "City", "Province"));
            lstDisplay.Items.Add("__________________________________________________________________________________________________________");
            while (!readerClient.EndOfStream)
            {
                record = readerClient.ReadLine();
                string[] Client = record.Split(new string[] { ":" }, StringSplitOptions.None);
                
             
                //Sorting by Project Number/Starting up the file
                if (populate == "Proj")
                {
                    lstDisplay.Items.Add(String.Format("{0, -20}{1, 15}{2, 15}{3, 15}", Client[0] + " " + Client[1], Client[4], Client[2], Client[3]));

                }
                //Filtering by Store name
                if (populate == "Store")
                {
                    if (Client[0].Contains(txtStoreName.Text) || Client[1].Contains(txtStoreName.Text))
                    {
                        lstDisplay.Items.Add(String.Format("{0, -20}{1, 15}{2, 15}{3, 15}", Client[0] + " " + Client[1], Client[4], Client[2], Client[3]));
                    }
                }
                //Filtering by Status
                if (populate == "FilterStatus")
                {
                    if (Client[4] == cmbFilterStatus.Text)
                    {
                        lstDisplay.Items.Add(String.Format("{0, -20}{1, 15}{2, 15}{3, 15}", Client[0] + " " + Client[1], Client[4], Client[2], Client[3]));
                    }
                }

                //Filtering by City
                if (populate == "FilterCity")
                {
                    if (Client[2] == cmbFilterCity.Text)
                    {
                        lstDisplay.Items.Add(String.Format("{0, -20}{1, 15}{2, 15}{3, 15}", Client[0] + " " + Client[1], Client[4], Client[2], Client[3]));
                    }
                }

                //Filtering by Province
                if (populate == "FilterProvince")
                {
                    if (Client[3] == cmbFilterProvince.Text)
                    {
                        lstDisplay.Items.Add(String.Format("{0, -20}{1, 15}{2, 15}{3, 15}", Client[0] + " " + Client[1], Client[4], Client[2], Client[3]));
                    }
                }

                //Creating a tally of completed/partial/Not started to display
                if (Client[4] == "Completed")
                {
                    completed++;
                }
                else if (Client[4] == "Partial")
                {
                    partial++;
                }
                else if (Client[4] == "Not Started")
                {
                    notStarted++;
                }
                count++;
            }
            lstDisplay.Items.Add("__________________________________________________________________________________________________________");
            readerClient.Close();
            txtCompleted.Text = Convert.ToString(completed);
            txtPartial.Text = Convert.ToString(partial);
            txtNotStarted.Text = Convert.ToString(notStarted);

        }

        private void ChangeVisibility()
        {
            ComboBox[] cmbCashs = new ComboBox[5] { cmbCash1, cmbCash2, cmbCash3, cmbCash4, cmbCash5 };
            GroupBox[] gbCashs = new GroupBox[5] { gbCash1, gbCash2, gbCash3, gbCash4, gbCash5 };

            for (int i = 0; i <= 4; i++)
            {
                if (cmbCashs[i].Text == "N/A")
                {
                    gbCashs[i].Visible = false;
                }
                else
                {
                    gbCashs[i].Visible = true;
                }
            }
        }

        private void cmbFilterStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbFilterCity.Text = "";
            cmbFilterProvince.Text = "";
            Populate("FilterStatus");
        }

        private void cmbFilterCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbFilterStatus.Text = "";
            cmbFilterProvince.Text = "";
            Populate("FilterCity");
        }

        private void cmbFilterProvince_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbFilterCity.Text = "";
            cmbFilterStatus.Text = "";
            Populate("FilterProvince");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            CSRNewProject CSRnew = new CSRNewProject();
            CSRnew.ShowDialog();
        }
    }
}
